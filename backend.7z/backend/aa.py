import sqlite3

conn = sqlite3.connect("university_fees.db")
cur = conn.cursor()

cur.execute("SELECT * FROM challans")
print(cur.fetchall())

cur.execute("SELECT * FROM students")
print(cur.fetchall())
