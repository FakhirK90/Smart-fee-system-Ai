import sqlite3
import os
from datetime import datetime, timedelta

DB_PATH = "university_fees.db"

def create_connection(path=DB_PATH):
    conn = sqlite3.connect(path, timeout=20)
    conn.row_factory = sqlite3.Row
    return conn

def create_tables(conn):
    cur = conn.cursor()

    # ---------- students ----------
    cur.execute("""
    CREATE TABLE IF NOT EXISTS students (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        roll_no TEXT UNIQUE,
        department TEXT,
        semester TEXT,
        phone TEXT,
        face_encoding BLOB
    );
    """)

    # ---------- fee structure ----------
    cur.execute("""
    CREATE TABLE IF NOT EXISTS fee_structure (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        semester TEXT,
        tuition_fee INTEGER,
        hostel_fee INTEGER,
        transport_fee INTEGER,
        total_fee INTEGER
    );
    """)

    # ---------- fees ----------
    cur.execute("""
    CREATE TABLE IF NOT EXISTS fees (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        roll_no TEXT,
        total_fee INTEGER,
        paid_amount INTEGER DEFAULT 0,
        status TEXT
    );
    """)

    # ---------- payments ----------
    cur.execute("""
    CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        roll_no TEXT,
        challan_no TEXT,  -- ✅ YE LINE ADD KAREIN (Ye Missing Thi)
        amount INTEGER,
        payment_method TEXT,
        status TEXT,
        date TEXT,
        receipt_path TEXT
    );
    """)
    

    # ---------- challans ----------
    cur.execute("""
    CREATE TABLE IF NOT EXISTS challans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        challan_no TEXT,
        roll_no TEXT,
        semester TEXT,
        total_amount INTEGER,
        due_date TEXT,
        status TEXT DEFAULT 'Unpaid',
        description TEXT
    );
    """)

    conn.commit()

def ensure_receipts_dir():
    if not os.path.exists("receipts"):
        os.makedirs("receipts")

def main():
    ensure_receipts_dir()
    conn = create_connection()
    create_tables(conn)
    conn.close()
    print("✅ Tables created successfully (no data inserted).")

if __name__ == "__main__":
    main()
