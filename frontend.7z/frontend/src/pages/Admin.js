import React, { useState, useEffect } from "react";
import axios from "axios";

function Admin() {
  const [students, setStudents] = useState([]);
  const [payments, setPayments] = useState([]);
  const [analytics, setAnalytics] = useState({});
  const [selectedStudent, setSelectedStudent] = useState("");
  const [history, setHistory] = useState([]);

  // Fetch all students, payments, analytics
  useEffect(() => {
    const fetchData = async () => {
      try {
        const s = await axios.get("http://localhost:5000/admin/students");
        setStudents(s.data.students);

        const p = await axios.get("http://localhost:5000/admin/payments");
        setPayments(p.data.payments);

        const a = await axios.get("http://localhost:5000/admin/analytics");
        setAnalytics(a.data);
      } catch (err) {
        console.log(err);
      }
    };
    fetchData();
  }, []);

  // Fetch payment history for a selected student
  const fetchHistory = async () => {
    if (!selectedStudent) return;
    try {
      const res = await axios.get(`http://localhost:5000/history/${selectedStudent}`);
      setHistory(res.data.history);
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h2>Admin Dashboard</h2>

      <h3>Analytics</h3>
      <p>Total Students: {analytics.total_students}</p>
      <p>Total Fees Collected: {analytics.total_collected}</p>
      <p>Pending Payments: {analytics.pending_payments}</p>

      <h3>All Students</h3>
      <ul>
        {students.map(s => (
          <li key={s.id}>{s.name} ({s.roll_no})</li>
        ))}
      </ul>

      <h3>All Payments</h3>
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>ID</th>
            <th>Roll No</th>
            <th>Amount</th>
            <th>Method</th>
            <th>Status</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          {payments.map(p => (
            <tr key={p.id}>
              <td>{p.id}</td>
              <td>{p.roll_no}</td>
              <td>{p.amount}</td>
              <td>{p.payment_method}</td>
              <td>{p.status}</td>
              <td>{p.date}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h3>Payment History by Student</h3>
      <input
        type="text"
        placeholder="Enter Roll No"
        value={selectedStudent}
        onChange={(e) => setSelectedStudent(e.target.value)}
      />
      <button onClick={fetchHistory}>Fetch History</button>

      {history.length > 0 && (
        <table border="1" cellPadding="5" style={{ marginTop: "10px" }}>
          <thead>
            <tr>
              <th>ID</th>
              <th>Amount</th>
              <th>Method</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {history.map(h => (
              <tr key={h.id}>
                <td>{h.id}</td>
                <td>{h.amount}</td>
                <td>{h.payment_method}</td>
                <td>{h.status}</td>
                <td>{h.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default Admin;
