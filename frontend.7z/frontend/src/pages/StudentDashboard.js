import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";
import Card from "../components/Card";
import Topbar from "../components/Topbar";

function StudentDashboard() {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const roll_no = params.get("roll_no");

  // State mein ab puri profile store karenge
  const [student, setStudent] = useState(null);
  const [history, setHistory] = useState([]);
  const [pendingChallan, setPendingChallan] = useState(null);
  const [stats, setStats] = useState({ paid: 0, pending: 0, dues: 0 });

  const fetchData = async () => {
    if (!roll_no) return;
    try {
      const BASE_URL = "http://localhost:5000";

      // 1. Get Full Student Profile (New API call)
      const profileRes = await axios.get(`${BASE_URL}/student/info/${roll_no}`);
      if (profileRes.data.success) {
        setStudent(profileRes.data.student);
      }

      // 2. Get Payment History
      const h = await axios.get(`${BASE_URL}/history/${roll_no}`);
      setHistory(h.data.history);

      // 3. Get Current Unpaid Challan
      const c = await axios.get(`${BASE_URL}/student/challan/${roll_no}`);
      
      let dues = 0;
      let pendingCount = 0;

      if (c.data.success) {
        setPendingChallan(c.data.challan);
        dues = c.data.challan.total_amount;
        pendingCount = 1;
      } else {
        setPendingChallan(null);
      }
      
      const totalPaid = h.data.history.reduce((sum, p) => sum + p.amount, 0);
      setStats({ paid: totalPaid, pending: pendingCount, dues: dues });

    } catch (err) {
      console.error("Error fetching data:", err);
    }
  };

  useEffect(() => {
    fetchData();
  }, [roll_no]);

  const handlePay = async () => {
    if (!pendingChallan) return;
    const confirm = window.confirm(`Pay PKR ${pendingChallan.total_amount} now?`);
    if (!confirm) return;

    try {
      const res = await axios.post("http://localhost:5000/pay", {
        challan_no: pendingChallan.challan_no,
        roll_no: roll_no,
        amount: pendingChallan.total_amount,
        payment_method: "Credit Card"
      });

      if (res.data.success) {
        alert("✅ Payment Successful!");
        fetchData(); 
      }
    } catch (err) {
      alert("Error processing payment");
    }
  };

  const handleDownload = (paymentId) => {
    window.open(`http://localhost:5000/receipt/${paymentId}`, "_blank");
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh", backgroundColor: "#f4f6f8" }}>
      <Topbar />

      <div style={{ padding: "30px", flex: 1, overflowY: "auto" }}>
        
        {/* Header Section with FULL DETAILS */}
        <div style={{ 
            background: "white", padding: "20px", borderRadius: "10px", 
            boxShadow: "0 2px 5px rgba(0,0,0,0.05)", marginBottom: "20px",
            display: "flex", justifyContent: "space-between", alignItems: "center"
        }}>
            <div>
                {/* Agar student data load ho gaya hai to details dikhao */}
                {student ? (
                    <>
                        <h2 style={{ margin: "0 0 10px 0", color: "#333" }}>Welcome, {student.name}</h2>
                        <div style={{ color: "#555", fontSize: "14px", lineHeight: "1.6" }}>
                            <strong>Roll No:</strong> {student.roll_no} <span style={{margin:"0 10px"}}>|</span>
                            <strong>Dept:</strong> {student.department} <span style={{margin:"0 10px"}}>|</span>
                            <strong>Semester:</strong> {student.semester} <span style={{margin:"0 10px"}}>|</span>
                            <strong>Phone:</strong> {student.phone}
                        </div>
                    </>
                ) : (
                    <h2>Loading Profile...</h2>
                )}
            </div>

            {/* Pay Button */}
            {stats.dues > 0 && (
                <div style={{ textAlign: "right" }}>
                    <div style={{ color: "red", fontWeight: "bold", marginBottom: "5px", fontSize: "18px" }}>
                        Due: PKR {stats.dues}
                    </div>
                    <button 
                        onClick={handlePay}
                        style={{
                            backgroundColor: "#28a745", color: "white", 
                            padding: "10px 25px", border: "none", 
                            borderRadius: "5px", cursor: "pointer", fontSize: "16px", fontWeight: "bold"
                        }}
                    >
                        Pay Now
                    </button>
                </div>
            )}
        </div>

        {/* Stats Cards */}
        <div style={{ display: "flex", gap: "20px" }}>
          <Card title="Total Paid" value={`PKR ${stats.paid}`} color="#4CAF50" />
          <Card title="Pending Challans" value={stats.pending} color="#FF9800" />
          <Card title="Current Dues" value={`PKR ${stats.dues}`} color="#F44336" />
        </div>

        {/* History Table */}
        <h3 style={{ marginTop: "30px" }}>Transaction History</h3>
        <div style={{ background: "white", padding: "20px", borderRadius: "10px", boxShadow: "0 2px 5px rgba(0,0,0,0.05)" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
                <tr style={{ background: "#f8f9fa", textAlign: "left", color: "#666" }}>
                <th style={{ padding: "12px" }}>Receipt ID</th>
                <th style={{ padding: "12px" }}>Amount</th>
                <th style={{ padding: "12px" }}>Method</th>
                <th style={{ padding: "12px" }}>Date</th>
                <th style={{ padding: "12px" }}>Action</th>
                </tr>
            </thead>
            <tbody>
                {history.map((p) => (
                <tr key={p.id} style={{ borderBottom: "1px solid #eee" }}>
                    <td style={{ padding: "12px" }}>#{p.id}</td>
                    <td style={{ padding: "12px" }}>{p.amount}</td>
                    <td style={{ padding: "12px" }}>{p.payment_method}</td>
                    <td style={{ padding: "12px" }}>{p.date}</td>
                    <td style={{ padding: "12px" }}>
                        <button 
                            onClick={() => handleDownload(p.id)}
                            style={{
                                padding: "6px 12px", backgroundColor: "#007bff", 
                                color: "white", border: "none", borderRadius: "4px", cursor: "pointer"
                            }}
                        >
                            Receipt
                        </button>
                    </td>
                </tr>
                ))}
                {history.length === 0 && (
                <tr>
                    <td colSpan="5" style={{ textAlign: "center", padding: "20px", color: "#999" }}>
                    No transactions found.
                    </td>
                </tr>
                )}
            </tbody>
            </table>
        </div>
      </div>
    </div>
  );
}

export default StudentDashboard;