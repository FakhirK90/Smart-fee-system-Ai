import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [challan, setChallan] = useState("");
  const [student, setStudent] = useState(null);
  const [cameraOn, setCameraOn] = useState(false);

  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const navigate = useNavigate();

  // --- Challan Verify ---
  const verifyChallan = async () => {
    try {
      const res = await axios.post(
        "http://127.0.0.1:5000/verify-challan",
        { challan_no: challan }
      );

      if (res.data.success) {
        setStudent(res.data.student);
        alert("✅ Challan Verified — Face Scanner Started");
        startCamera();
      } else {
        alert(res.data.message || "Invalid Challan!");
      }
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || "Error verifying challan!");
    }
  };

  // --- Start Camera ---
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      videoRef.current.srcObject = stream;
      setCameraOn(true);
    } catch (err) {
      alert("❌ Cannot access camera!");
    }
  };

  // --- Stop Camera ---
  const stopCamera = () => {
    const stream = videoRef.current?.srcObject;
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }
    setCameraOn(false);
  };

  // --- AUTO FACE CAPTURE EVERY 1.2 sec ---
  useEffect(() => {
    if (cameraOn) {
      const interval = setInterval(() => {
        autoCapture();
      }, 1200);

      return () => clearInterval(interval);
    }
  }, [cameraOn]);

  // --- AUTO CAPTURE FRAME ---
  const autoCapture = async () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;

    if (!video || video.videoWidth === 0) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    canvas.getContext("2d").drawImage(video, 0, 0);
    canvas.toBlob(handleLogin, "image/jpeg");
  };

  // --- FACE LOGIN API ---
  // --- FACE LOGIN API ---
  // 
 // --- FACE LOGIN API ---
  // --- FACE LOGIN API (UPDATED FOR GROUP SCAN) ---
  const handleLogin = async (faceBlob) => {
    // Note: Ab hum student.roll_no check nahi kar rahe, sirf challan hona chahiye
    if (!challan) { 
        alert("Please enter Challan Number first");
        return; 
    }

    try {
      const formData = new FormData();
      formData.append("challan_no", challan); // Roll No ki jagah Challan bhej rahe hain
      formData.append("face_image", faceBlob);

      const BASE_URL = window.location.hostname === "localhost"
        ? "http://127.0.0.1:5000"
        : "http://192.168.0.41:5000";

      const res = await axios.post(`${BASE_URL}/face-login`, formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });

      if (res.data.success) {
        console.log("✅ Success:", res.data);
        alert(`✅ Face Matched! Welcome.`);
        stopCamera();
        // Redirect to THAT specific student's dashboard
        navigate(`/student/dashboard?roll_no=${res.data.roll_no}`);
      }
    } catch (err) {
      if (err.response && err.response.status !== 401) {
         // 401 (Mismatch) ko ignore karein taaki retry hota rahe
         console.error("Server Error:", err.response.data.message);
      }
    }
  };
    return (
    <div style={{ maxWidth: "400px", margin: "auto", paddingTop: "40px" }}>
      {!student ? (
        <>
          <h2>Student Login</h2>

          <input
            type="text"
            placeholder="Enter Challan Number"
            value={challan}
            onChange={(e) => setChallan(e.target.value)}
            style={{ width: "100%", padding: "10px" }}
          />

          <br /><br />

          <button onClick={verifyChallan}>
            Verify Challan & Start Face Login
          </button>
        </>
      ) : (
        <>
          <h3>🔍 Face Scanner Active</h3>

          <video
            ref={videoRef}
            autoPlay
            playsInline
            style={{ width: "100%", borderRadius: "10px" }}
          />

          <canvas ref={canvasRef} hidden />

          <p style={{ textAlign: "center" }}>
            Please look at the camera for automatic login
          </p>
        </>
      )}
    </div>
  );
}
