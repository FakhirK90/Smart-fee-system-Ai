import React, { useState } from "react";
import axios from "axios";

function Register() {
  const [name, setName] = useState("");
  const [roll, setRoll] = useState("");
  const [phone, setPhone] = useState("");
  const [department, setDept] = useState("");
  const [semester, setSem] = useState("");
  const [face, setFace] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append("name", name);
    formData.append("roll_no", roll);
    formData.append("phone", phone);
    formData.append("department", department);
    formData.append("semester", semester);
    formData.append("face_image", face);

    try {
      const res = await axios.post("http://localhost:5000/register", formData);
      alert(res.data.message);
    } catch (err) {
      console.log(err);
      alert(err.response?.data?.message || "Error registering student");
    }
  };

  return (
    <div style={{ maxWidth: "400px", margin: "auto", paddingTop: "50px" }}>
      <h2>Student Registration</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Name" onChange={e=>setName(e.target.value)} required /><br /><br />
        <input type="text" placeholder="Roll No" onChange={e=>setRoll(e.target.value)} required /><br /><br />
        <input type="text" placeholder="Phone" onChange={e=>setPhone(e.target.value)} required /><br /><br />
        <input type="text" placeholder="Department" onChange={e=>setDept(e.target.value)} required /><br /><br />
        <input type="text" placeholder="Semester" onChange={e=>setSem(e.target.value)} required /><br /><br />
        <input type="file" accept="image/*" onChange={e=>setFace(e.target.files[0])} required /><br /><br />
        <button type="submit">Register</button>
      </form>
    </div>
  );
}

export default Register;
