import React, { useEffect, useState } from "react";
import axios from "axios";
import Card from "../components/Card";
import Topbar from "../components/Topbar";

function Admin() {
  const [students, setStudents] = useState([]);
  const [payments, setPayments] = useState([]);
  const [analytics, setAnalytics] = useState({});

  useEffect(() => {
    const fetchData = async () => {
      const s = await axios.get("http://localhost:5000/admin/students");
      setStudents(s.data.students);

      const p = await axios.get("http://localhost:5000/admin/payments");
      setPayments(p.data.payments);

      const a = await axios.get("http://localhost:5000/admin/analytics");
      setAnalytics(a.data);
    };
    fetchData();
  }, []);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100vh" }}>
      <Topbar />

      <div style={{ padding: "20px", flex: 1, overflowY: "auto" }}>
        <h2>Admin Dashboard</h2>

        {/* Analytics Cards */}
        <div style={{ display: "flex", gap: "20px", marginTop: "20px" }}>
          <Card title="Total Students" value={analytics.total_students} color="#4CAF50" />
          <Card title="Total Fees Collected" value={analytics.total_collected} color="#2196F3" />
          <Card title="Pending Payments" value={analytics.pending_payments} color="#FF5722" />
        </div>

        {/* Students Table */}
        <h3 style={{ marginTop: "40px" }}>All Students</h3>
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "10px" }}>
          <thead>
            <tr style={{ background: "#f0f0f0" }}>
              <th>ID</th>
              <th>Name</th>
              <th>Roll No</th>
              <th>Phone</th>
              <th>Department</th>
              <th>Semester</th>
            </tr>
          </thead>
          <tbody>
            {students.map((s) => (
              <tr key={s.id} style={{ borderBottom: "1px solid #ddd" }}>
                <td>{s.id}</td>
                <td>{s.name}</td>
                <td>{s.roll_no}</td>
                <td>{s.phone}</td>
                <td>{s.department}</td>
                <td>{s.semester}</td>
              </tr>
            ))}
          </tbody>
        </table>

        {/* Payments Table */}
        <h3 style={{ marginTop: "40px" }}>All Payments</h3>
        <table style={{ width: "100%", borderCollapse: "collapse", marginTop: "10px" }}>
          <thead>
            <tr style={{ background: "#f0f0f0" }}>
              <th>ID</th>
              <th>Roll No</th>
              <th>Amount</th>
              <th>Method</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {payments.map((p) => (
              <tr key={p.id} style={{ borderBottom: "1px solid #ddd" }}>
                <td>{p.id}</td>
                <td>{p.roll_no}</td>
                <td>{p.amount}</td>
                <td>{p.payment_method}</td>
                <td>{p.status}</td>
                <td>{p.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default Admin;
