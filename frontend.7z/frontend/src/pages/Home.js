// src/pages/Home.js
import React from "react";
import { Link } from "react-router-dom";

function Home() {
  return (
    <div style={styles.container}>
      <div style={styles.content}>
        <h1 style={styles.title}>University Fee Management System</h1>
        <p style={styles.subtitle}>Select an option to proceed</p>

        <div style={styles.grid}>
          {/* Option 1: Student Login */}
          <div style={styles.card}>
            <h3>🎓 Student Portal</h3>
            <p>Login with Face ID to pay fees & view history.</p>
            <Link to="/login">
              <button style={{...styles.btn, background: "#007bff"}}>Student Login</button>
            </Link>
          </div>

          {/* Option 2: New Admission */}
          <div style={styles.card}>
            <h3>📝 New Admission</h3>
            <p>Register yourself for the new semester.</p>
            <Link to="/register">
              <button style={{...styles.btn, background: "#28a745"}}>Register Now</button>
            </Link>
          </div>

          {/* Option 3: Admin Portal */}
          <div style={styles.card}>
            <h3>🔒 Admin Portal</h3>
            <p>Authorized staff access only.</p>
            <Link to="/admin">
              <button style={{...styles.btn, background: "#343a40"}}>Admin Dashboard</button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

// Simple CSS Styles (Isi file mein)
const styles = {
  container: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f4f6f8",
    fontFamily: "Arial, sans-serif",
  },
  content: {
    textAlign: "center",
    maxWidth: "900px",
    padding: "20px",
  },
  title: {
    color: "#333",
    fontSize: "36px",
    marginBottom: "10px",
  },
  subtitle: {
    color: "#666",
    marginBottom: "40px",
    fontSize: "18px",
  },
  grid: {
    display: "flex",
    gap: "20px",
    justifyContent: "center",
    flexWrap: "wrap",
  },
  card: {
    background: "white",
    padding: "30px",
    borderRadius: "10px",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
    width: "250px",
    textAlign: "center",
  },
  btn: {
    color: "white",
    padding: "10px 20px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
    fontSize: "16px",
    marginTop: "15px",
    width: "100%",
  }
};

export default Home;