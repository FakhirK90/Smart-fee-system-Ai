import React from "react";

const Card = ({ title, value, color }) => {
  return (
    <div style={{
      background: color || "#1E90FF",
      color: "#fff",
      padding: "20px",
      borderRadius: "10px",
      margin: "10px",
      flex: 1,
      textAlign: "center",
      boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
    }}>
      <h3>{title}</h3>
      <h2>{value}</h2>
    </div>
  );
};

export default Card;
