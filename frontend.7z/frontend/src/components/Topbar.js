import React from "react";

const Topbar = () => {
  return (
    <div style={{
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "10px 20px",
      background: "#f5f5f5",
      borderBottom: "1px solid #ddd"
    }}>
      <div style={{ fontWeight: "bold", fontSize: "20px" }}>University Logo</div>
      <input 
        type="text" 
        placeholder="Search..." 
        style={{ padding: "5px 10px", borderRadius: "5px", border: "1px solid #ccc" }}
      />
      <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
        <div style={{ cursor: "pointer" }}>🔔</div>
        <div style={{ width: "30px", height: "30px", borderRadius: "50%", background: "#1E90FF", color: "#fff", display: "flex", alignItems: "center", justifyContent: "center" }}>
          A
        </div>
      </div>
    </div>
  );
};

export default Topbar;
