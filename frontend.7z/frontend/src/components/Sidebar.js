import React from "react";
import { Link } from "react-router-dom";

const Sidebar = ({ role }) => {
  return (
    <div style={{ width: "200px", background: "#1E90FF", color: "#fff", height: "100vh", padding: "20px" }}>
      <h2>{role} Dashboard</h2>
      {role === "student" ? (
        <ul>
          <li><Link to="/student/dashboard">Dashboard</Link></li>
          <li><Link to="/student/fees">Fees</Link></li>
          <li><Link to="/student/history">History</Link></li>
          <li><Link to="/student/profile">Profile</Link></li>
          <li><Link to="/student/receipts">Receipts</Link></li>
          <li><Link to="/student/notifications">Notifications</Link></li>
        </ul>
      ) : (
        <ul>
          <li><Link to="/admin/dashboard">Dashboard</Link></li>
          <li><Link to="/admin/manage-students">Manage Students</Link></li>
          <li><Link to="/admin/manage-payments">Manage Payments</Link></li>
          <li><Link to="/admin/analytics">Analytics</Link></li>
          <li><Link to="/admin/reports">Reports</Link></li>
        </ul>
      )}
    </div>
  );
};

export default Sidebar;
