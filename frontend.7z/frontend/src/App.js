import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import Register from "./pages/Register";
import Login from "./pages/Login";
import StudentDashboard from "./pages/StudentDashboard";
import AdminDashboard from "./pages/AdminDashboard";
import AdminLogin from "./pages/AdminLogin"; // ✅ Import New File

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} /> 
        
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/student/dashboard" element={<StudentDashboard />} />
        
        {/* ✅ Admin Routes Changed */}
        <Route path="/admin" element={<AdminLogin />} /> 
        <Route path="/admin/dashboard" element={<AdminDashboard />} /> 

      </Routes>
    </Router>
  );
}

export default App;