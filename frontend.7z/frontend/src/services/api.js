import axios from "axios";

const API_URL = "http://localhost:5000";

export const getStudentHistory = (roll_no) =>
  axios.get(`${API_URL}/history/${roll_no}`);

export const getAdminStudents = () =>
  axios.get(`${API_URL}/admin/students`);

export const getAdminPayments = () =>
  axios.get(`${API_URL}/admin/payments`);

export const getAdminAnalytics = () =>
  axios.get(`${API_URL}/admin/analytics`);
